# Submission Checklist

Student: Mohammad Yaqoob Arif  
Student ID: 34

## Task 1 — PHP and Composer
- [ ] `php -v` shows PHP 8.2 or newer.
- [ ] `composer --version` works.

## Task 2 — Laravel Project
- [ ] Laravel 12 project created.
- [ ] `php artisan --version` reports Laravel 12.x.
- [ ] Project opens correctly in the code editor.

## Task 3 — Blade View
- [x] `resources/views/home.blade.php` created.
- [x] Student name updated.
- [x] Course variable displayed using Blade syntax.

## Task 4 — Route
- [x] `/` GET route exists.
- [x] Home route returns the `home` view.
- [x] Course value is passed to the view.
- [x] Session and cache use file drivers.
- [x] `php artisan config:clear` is documented.
- [x] `php artisan serve` is documented.

## Task 5 — Own Page
- [x] `resources/views/about.blade.php` created.
- [x] Full name displayed.
- [x] Student ID displayed.
- [x] Two learning sentences included.
- [x] `/about` GET route exists.
- [x] Home page links to `/about`.
- [x] About page links back to `/`.

## Recommended Screenshots for Teacher

1. `php -v`
2. `composer --version`
3. `php artisan --version`
4. Project folder in VS Code
5. Home page at `/`
6. About page at `/about`
7. Terminal showing `php artisan serve`
8. GitHub repository showing project files

The screenshots are evidence of execution on the student's computer and should be captured after running the project locally.
