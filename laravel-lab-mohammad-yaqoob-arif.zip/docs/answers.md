# Quick Understanding Questions — Answers

## 1. In which folder do you place Blade view files?

Blade view files are placed in:

`resources/views`

## 2. Which file contains the routes used in this lab?

The routes are defined in:

`routes/web.php`

## 3. What does `return view('home')` do?

It loads and returns the `home` Blade view, which corresponds to:

`resources/views/home.blade.php`

In this lab, the route also passes the `course` variable to the view.

## 4. What is the difference between the URL `/about` and the file `about.blade.php`?

`/about` is a browser URL/path handled by a Laravel route.

`about.blade.php` is a Blade template file stored in `resources/views`.

The `/about` route returns the `about` view, which Laravel resolves to `about.blade.php`.
