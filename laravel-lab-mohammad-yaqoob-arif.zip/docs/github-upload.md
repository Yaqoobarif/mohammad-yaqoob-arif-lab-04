# GitHub Upload Guide

## Repository

Recommended repository name:

`laravel-beginner-lab-mohammad-yaqoob-arif`

## Commands

Open Command Prompt inside this project folder:

```bash
git init
git add .
git commit -m "Complete Laravel Beginner Lab 1"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Replace `YOUR_GITHUB_REPOSITORY_URL` with the URL of the GitHub repository you create.

## Before Push

Make sure `.env` and `vendor/` are not uploaded. The `.gitignore` file already excludes them.

## What the Teacher Can Inspect

- `routes/web.php`
- `resources/views/home.blade.php`
- `resources/views/about.blade.php`
- `.env.example`
- `README.md`
- `docs/answers.md`
- `docs/submission-checklist.md`
