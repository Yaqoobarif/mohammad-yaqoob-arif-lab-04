<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Me - Laravel Lab</title>
</head>
<body>
    <h1>About Me</h1>

    <p><strong>Full Name:</strong> Mohammad Yaqoob Arif</p>
    <p><strong>Student ID:</strong> 34</p>

    <p>
        I want to learn how Laravel routes, Blade views, and PHP work together
        to build modern web applications.
    </p>

    <p>
        I also want to improve my practical skills in web development and
        understand how to organize Laravel projects correctly.
    </p>

    <p>
        <a href="{{ url('/') }}">Return to Home</a>
    </p>
</body>
</html>
